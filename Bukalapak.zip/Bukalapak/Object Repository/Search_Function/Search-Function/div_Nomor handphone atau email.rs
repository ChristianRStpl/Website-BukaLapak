<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Nomor handphone atau email</name>
   <tag></tag>
   <elementGuidId>c5cf4fa9-e30c-4012-b7b2-44c2dda9f2f4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.bl-text-field__inner</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Lanjut'])[1]/preceding::div[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>88125ea4-6cd6-42cf-bf78-2d13118d2422</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bl-text-field__inner</value>
      <webElementGuid>819a4b4a-02a3-4a2d-8fc4-c15875802730</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Nomor handphone atau email</value>
      <webElementGuid>adf525c5-5ec7-491e-90e2-d680c6b93b1a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[1]/main[@class=&quot;plf__wrapper&quot;]/div[@class=&quot;plf__container&quot;]/div[@class=&quot;plf__bl-card bl-card has-elevation-1 bl-card--outlined&quot;]/section[1]/section[@class=&quot;position__relative&quot;]/div[@class=&quot;container-flf&quot;]/div[@class=&quot;wrapper-input-identity&quot;]/div[@class=&quot;bl-text-field transition__basic&quot;]/div[@class=&quot;bl-text-field__boxed&quot;]/div[@class=&quot;bl-text-field__inner&quot;]</value>
      <webElementGuid>5208b8e4-8505-458d-9030-3279194466a4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lanjut'])[1]/preceding::div[3]</value>
      <webElementGuid>3158da20-ac9f-4b6c-a00c-4bb346ff6565</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div</value>
      <webElementGuid>f88bb6de-f81d-46fd-913a-06f6fec14ff0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = ' Nomor handphone atau email' or . = ' Nomor handphone atau email')]</value>
      <webElementGuid>1e541644-436f-4f24-836c-499749c90149</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
