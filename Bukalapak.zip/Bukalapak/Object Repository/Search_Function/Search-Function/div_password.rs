<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_password</name>
   <tag></tag>
   <elementGuidId>8fd5e391-de67-40eb-af33-209af0b1dc29</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.mb-20.transition__basic.transform__right.transform__normal > div.bl-text-field > div.bl-text-field__boxed > div.bl-text-field__inner</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Lanjut'])[1]/following::div[16]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>ba42551f-4bd4-40b0-9116-35ced1258d08</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bl-text-field__inner</value>
      <webElementGuid>3ad733c6-c62f-4940-9723-34cf6fe28b37</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> password</value>
      <webElementGuid>e6d5ced9-a154-4fc1-9813-df77db926e8c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[1]/main[@class=&quot;plf__wrapper&quot;]/div[@class=&quot;plf__container&quot;]/div[@class=&quot;plf__bl-card bl-card has-elevation-1 bl-card--outlined&quot;]/section[1]/section[@class=&quot;container-ipl z-index__front&quot;]/div[@class=&quot;wrapper-form-ipl&quot;]/div[@class=&quot;mb-20 transition__basic transform__right transform__normal&quot;]/div[@class=&quot;bl-text-field&quot;]/div[@class=&quot;bl-text-field__boxed&quot;]/div[@class=&quot;bl-text-field__inner&quot;]</value>
      <webElementGuid>ac8359a7-28cf-44b3-a620-32340b431c3d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lanjut'])[1]/following::div[16]</value>
      <webElementGuid>591111eb-7c44-44d5-8c24-82834a5c8e0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nomor handphone atau email'])[1]/following::div[19]</value>
      <webElementGuid>dfbb1ca3-a4ba-429d-8097-7eb47469b44c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lupa Password?'])[1]/preceding::div[3]</value>
      <webElementGuid>32a284ec-3f6d-4093-94d8-80b5d9cf8a41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div</value>
      <webElementGuid>7043dafd-2069-41f7-89b9-15b34f073717</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = ' password' or . = ' password')]</value>
      <webElementGuid>cfaf534d-8b9c-4910-991d-2c3db2be2cb4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
