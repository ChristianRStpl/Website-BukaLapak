<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_password</name>
   <tag></tag>
   <elementGuidId>ebe1e140-ce63-4393-98c3-5894ccbb5411</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.mb-20.transition__basic.transform__right.transform__normal > div.bl-text-field > div.bl-text-field__boxed > div.bl-text-field__inner</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Lanjut'])[1]/following::div[16]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>84ec50c3-07c5-45ff-b623-767416b93ae6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bl-text-field__inner</value>
      <webElementGuid>abfc840c-96a1-44e1-aa92-f7b05e4f5d54</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> password</value>
      <webElementGuid>788f5086-6cdb-4cd5-ba24-f8b8a82256e4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[1]/main[@class=&quot;plf__wrapper&quot;]/div[@class=&quot;plf__container&quot;]/div[@class=&quot;plf__bl-card bl-card has-elevation-1 bl-card--outlined&quot;]/section[1]/section[@class=&quot;container-ipl z-index__front&quot;]/div[@class=&quot;wrapper-form-ipl&quot;]/div[@class=&quot;mb-20 transition__basic transform__right transform__normal&quot;]/div[@class=&quot;bl-text-field&quot;]/div[@class=&quot;bl-text-field__boxed&quot;]/div[@class=&quot;bl-text-field__inner&quot;]</value>
      <webElementGuid>0fdb7962-e0fd-41bc-8401-a1b7292225aa</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lanjut'])[1]/following::div[16]</value>
      <webElementGuid>4109247f-b782-44f3-b057-5690cd6869df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nomor handphone atau email'])[1]/following::div[19]</value>
      <webElementGuid>e20f1aad-7677-4c49-bb17-3be113a7d439</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lupa Password?'])[1]/preceding::div[3]</value>
      <webElementGuid>3dd9eb6f-32d1-4920-9c30-6a85064c5156</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div</value>
      <webElementGuid>75081641-d7d0-47b9-bb90-78b8f2667a8b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = ' password' or . = ' password')]</value>
      <webElementGuid>1db05b45-edb5-4b8b-aee1-a69a59e8e67a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
