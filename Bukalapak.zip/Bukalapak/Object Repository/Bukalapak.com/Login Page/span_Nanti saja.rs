<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Nanti saja</name>
   <tag></tag>
   <elementGuidId>d1062fc2-828e-4940-b7d7-396e803faa24</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#create-pin-btn-secondary > span.bl-text.bl-text--body-default.bl-text--semi-bold</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@id='create-pin-btn-secondary']/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>d2aa0e70-5176-4015-9a6f-11efebfe888f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bl-text bl-text--body-default bl-text--semi-bold</value>
      <webElementGuid>b9824f4c-b0ab-4cdb-a78f-38222d477ede</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Nanti saja</value>
      <webElementGuid>4a48514d-9ac0-4d2d-b9e0-ef12a7f16d07</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;create-pin-btn-secondary&quot;)/span[@class=&quot;bl-text bl-text--body-default bl-text--semi-bold&quot;]</value>
      <webElementGuid>e0c989fb-cc4d-4091-a6be-1b428941293d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//button[@id='create-pin-btn-secondary']/span</value>
      <webElementGuid>ea62f31b-81b6-4d99-8684-9040cfa53298</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Buat PIN sekarang'])[1]/following::span[1]</value>
      <webElementGuid>d5d099e0-5d11-46ba-beb7-812f0f497ecf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/following::span[3]</value>
      <webElementGuid>39401068-fb40-47a8-b0c4-a81d40271da0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Nanti saja']/parent::*</value>
      <webElementGuid>73e8d714-2650-4ed4-b3f5-362345d0c22a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button[2]/span</value>
      <webElementGuid>296f495e-ccc8-4e22-82c9-b42087c1dee7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Nanti saja' or . = 'Nanti saja')]</value>
      <webElementGuid>1d99668a-3fd7-450e-948f-3c22cb53d4d9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
