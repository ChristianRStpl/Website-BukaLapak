<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_User tidak ditemukan</name>
   <tag></tag>
   <elementGuidId>55c2fa2f-1ab1-4d0a-a1d1-3930d5892431</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p.bl-text.bl-text--caption.bl-text--error</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//p[(text() = '
        User tidak ditemukan
      ' or . = '
        User tidak ditemukan
      ')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Nomor handphone atau email'])[1]/following::p[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>76ad963f-d753-4a0f-adcd-12fc439afb65</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bl-text bl-text--caption bl-text--error</value>
      <webElementGuid>c699e8b1-e5ff-4fdb-97be-918576378bfc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        User tidak ditemukan
      </value>
      <webElementGuid>056723ee-a5c9-4614-92cf-5d2faba6704e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[1]/main[@class=&quot;plf__wrapper&quot;]/div[@class=&quot;plf__container&quot;]/div[@class=&quot;plf__bl-card bl-card has-elevation-1 bl-card--outlined&quot;]/section[1]/section[@class=&quot;position__relative&quot;]/div[@class=&quot;container-flf&quot;]/div[@class=&quot;wrapper-input-identity&quot;]/div[@class=&quot;bl-text-field transition__basic has-value is-error&quot;]/div[2]/div[@class=&quot;bl-text-field__message&quot;]/p[@class=&quot;bl-text bl-text--caption bl-text--error&quot;]</value>
      <webElementGuid>4811294b-9757-4a06-8735-662f765824f5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nomor handphone atau email'])[1]/following::p[1]</value>
      <webElementGuid>7f2e79b1-059d-437a-b097-323aeada6350</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lanjut'])[1]/preceding::p[1]</value>
      <webElementGuid>02480874-fc83-4474-af61-0de5a1aa52ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Facebook'])[1]/preceding::p[2]</value>
      <webElementGuid>60be756a-0349-4981-bae7-efc444fe4a64</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='User tidak ditemukan']/parent::*</value>
      <webElementGuid>dedea16f-6659-4f51-99ff-c3ab93d5f4e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[2]/div/p</value>
      <webElementGuid>1774c1af-482b-49c6-9a2e-7ccd9f92be07</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '
        User tidak ditemukan
      ' or . = '
        User tidak ditemukan
      ')]</value>
      <webElementGuid>e93e4e9b-bb0d-4a6b-866d-1bc13c06da18</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
