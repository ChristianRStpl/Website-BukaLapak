<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Password wajib diisi, ya</name>
   <tag></tag>
   <elementGuidId>92fbda22-e148-44b3-8b3b-40a1265ca163</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p.bl-text.bl-text--caption.bl-text--error</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//p[(text() = '
        Password wajib diisi, ya.
      ' or . = '
        Password wajib diisi, ya.
      ')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='password'])[1]/following::p[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>8f97be6b-944a-4a6b-9131-f50e350c32d8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bl-text bl-text--caption bl-text--error</value>
      <webElementGuid>aa1c4720-5c7f-4f5d-a798-991f0ff2e4e2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        Password wajib diisi, ya.
      </value>
      <webElementGuid>9b6c6c18-e240-474a-90cd-def600fc8403</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[1]/main[@class=&quot;plf__wrapper&quot;]/div[@class=&quot;plf__container&quot;]/div[@class=&quot;plf__bl-card bl-card has-elevation-1 bl-card--outlined&quot;]/section[1]/section[@class=&quot;container-ipl z-index__front&quot;]/div[@class=&quot;wrapper-form-ipl&quot;]/div[@class=&quot;mb-20 transition__basic transform__right transform__normal&quot;]/div[@class=&quot;bl-text-field is-error&quot;]/div[2]/div[@class=&quot;bl-text-field__message&quot;]/p[@class=&quot;bl-text bl-text--caption bl-text--error&quot;]</value>
      <webElementGuid>ce79c091-3164-417e-b5ab-1f25f9ab37f4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='password'])[1]/following::p[1]</value>
      <webElementGuid>fc1122cf-b47d-4833-aecf-12ac5226e247</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lanjut'])[1]/following::p[5]</value>
      <webElementGuid>18794925-f52c-4538-be3d-ec604fe84e78</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lupa Password?'])[1]/preceding::p[1]</value>
      <webElementGuid>a1ed1da9-c1fa-4e43-aabb-88a90a057ee0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/preceding::p[2]</value>
      <webElementGuid>ae934e35-8c76-480a-9cb2-3cf3b48d7e1c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Password wajib diisi, ya.']/parent::*</value>
      <webElementGuid>29d2db47-c7af-4b6c-ae15-7d4e0b9f9718</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/div/p</value>
      <webElementGuid>f29e527d-144d-4eb8-b41e-a91d391acde9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '
        Password wajib diisi, ya.
      ' or . = '
        Password wajib diisi, ya.
      ')]</value>
      <webElementGuid>62aa0f41-80cb-44c0-ae09-91603c0ece1c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
