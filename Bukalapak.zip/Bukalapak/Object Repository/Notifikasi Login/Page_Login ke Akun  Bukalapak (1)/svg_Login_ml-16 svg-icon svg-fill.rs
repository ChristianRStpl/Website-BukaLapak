<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Login_ml-16 svg-icon svg-fill</name>
   <tag></tag>
   <elementGuidId>ce09d222-38d9-4762-8ad5-46c994d4a033</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>svg.ml-16.svg-icon.svg-fill</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/following::*[name()='svg'][1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>e338d845-258b-4d86-af05-052c79e48766</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>version</name>
      <type>Main</type>
      <value>1.1</value>
      <webElementGuid>f2ebfd46-7385-4fa1-9c52-4aa6f09d5033</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 24 24</value>
      <webElementGuid>4562fbd7-e4a7-47cd-97d1-e4423f629091</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ml-16 svg-icon svg-fill</value>
      <webElementGuid>e907f8a0-23f3-446b-a239-bdfcd8047d2f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[1]/main[@class=&quot;plf__wrapper&quot;]/div[@class=&quot;plf__container&quot;]/div[@class=&quot;plf__bl-card bl-card has-elevation-1 bl-card--outlined&quot;]/section[1]/div[@class=&quot;bl-modal p-24&quot;]/div[@class=&quot;bl-modal__wrapper&quot;]/div[@class=&quot;bl-card&quot;]/div[@class=&quot;bl-modal__header&quot;]/div[@class=&quot;bl-flex-container p-24 m-0 align-items-center&quot;]/div[@class=&quot;bl-flex-item&quot;]/svg[@class=&quot;ml-16 svg-icon svg-fill&quot;]</value>
      <webElementGuid>d1de78c5-4759-4bc8-957b-99f5957b6ab4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>4e803030-a92d-456a-ab80-fa7f03d63f39</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lupa Password?'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>621e9724-d20d-462f-9a1c-c04e8e873846</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Buat PIN sekarang'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>b845b581-8daf-4e10-bf41-ae3057ef60ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nanti saja'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>de00b263-3a1a-4ff6-ae22-850d83039263</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
